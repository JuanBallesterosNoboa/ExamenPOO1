﻿using System.Data;
using Microsoft.Data.SqlClient;
using ExamenPOO1.Config;

namespace ExamenPOO1.Controladores
{
    public class Proyectos_Controller
    {
        private static Conexion cn = new Conexion();

        public static DataTable Seleccionarproyecto()
        {
            using (SqlConnection con = cn.obtener_conexion())
            {
                      SqlDataAdapter da = new SqlDataAdapter(
                    "SELECT idProyecto, Nombre, FechaInicio FROM Proyectos", con);

                DataTable tabla = new DataTable();
                da.Fill(tabla);
                return tabla;
            }
        }

        public static void Insertarproyecto(string nombre, DateTime fecha)
        {
            using (SqlConnection con = cn.obtener_conexion())
            {
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Proyectos (Nombre, FechaInicio) VALUES (@n, @f)", con);

                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@f", fecha);

                cmd.ExecuteNonQuery();
            }
        }

        public static void Eliminarproyecto(int id)
        {
            using (SqlConnection con = cn.obtener_conexion())
            {
                SqlCommand cmd = new SqlCommand(
                    "DELETE FROM Proyectos WHERE idProyecto = @id", con);

                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
