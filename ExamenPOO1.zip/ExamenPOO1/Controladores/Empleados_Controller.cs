﻿using System.Data;
using Microsoft.Data.SqlClient;
using ExamenPOO1.Config;

namespace ExamenPOO1.Controladores
{
    public class Empleados_Controller
    {
        private static Conexion cn = new Conexion();

        public static DataTable Seleccionar()
        {
            using (SqlConnection con = cn.obtener_conexion())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Empleados", con);
                DataTable tabla = new DataTable();
                da.Fill(tabla);
                return tabla;
            }
        }

        public static void Insertar(string nombre, string puesto)
        {
            using (SqlConnection con = cn.obtener_conexion())
            {
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Empleados (Nombre, Puesto) VALUES (@n, @p)", con);

                cmd.Parameters.AddWithValue("@n", nombre);
                cmd.Parameters.AddWithValue("@p", puesto);

                cmd.ExecuteNonQuery();
            }
        }
        public static void Eliminar(int id)
        {
            Conexion conexion = new Conexion();

            using (SqlConnection cn = conexion.obtener_conexion())
            {
                string query = "DELETE FROM Empleados WHERE idEmpleado = @id";

                using (SqlCommand cmd = new SqlCommand(query, cn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

    }
    }
