﻿using System.Data;
using Microsoft.Data.SqlClient;
using ExamenPOO1.Config;

namespace ExamenPOO1.Controladores
{
    public static class Participaciones_Controller
    {
        private static readonly Conexion cn = new Conexion();

        // Seleccionar todas las participaciones
        public static DataTable SeleccionarTodas()
        {
            using (SqlConnection con = cn.obtener_conexion())
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandText =
                @"SELECT p.idParticipacion,
                         p.idEmpleado,
                         e.Nombre AS Empleado,
                         p.idProyecto,
                         pr.Nombre AS Proyecto,
                         p.Rol
                  FROM Participaciones p
                  INNER JOIN Empleados e ON p.idEmpleado = e.idEmpleado
                  INNER JOIN Proyectos pr ON p.idProyecto = pr.idProyecto";

                DataTable dt = new DataTable();
                new SqlDataAdapter(cmd).Fill(dt);
                return dt;
            }
        }

        // Seleccionar participaciones por proyecto
        public static DataTable SeleccionarPorProyecto(int idProyecto)
        {
            using (SqlConnection con = cn.obtener_conexion())
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandText =
                @"SELECT p.idParticipacion,
                         p.idEmpleado,
                         e.Nombre AS Empleado,
                         p.idProyecto,
                         pr.Nombre AS Proyecto,
                         p.Rol
                  FROM Participaciones p
                  INNER JOIN Empleados e ON p.idEmpleado = e.idEmpleado
                  INNER JOIN Proyectos pr ON p.idProyecto = pr.idProyecto
                  WHERE p.idProyecto = @id";

                cmd.Parameters.AddWithValue("@id", idProyecto);

                DataTable dt = new DataTable();
                new SqlDataAdapter(cmd).Fill(dt);
                return dt;
            }
        }

        // Insertar
        public static int Insertar(int idEmpleado, int idProyecto, string rol)
        {
            using (SqlConnection con = cn.obtener_conexion())
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandText =
                @"INSERT INTO Participaciones (idEmpleado, idProyecto, Rol)
                  VALUES (@e, @p, @r);
                  SELECT SCOPE_IDENTITY();";

                cmd.Parameters.AddWithValue("@e", idEmpleado);
                cmd.Parameters.AddWithValue("@p", idProyecto);
                cmd.Parameters.AddWithValue("@r", (object)rol ?? DBNull.Value);

                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        // Eliminar
        public static bool Eliminar(int idParticipacion)
        {
            using (SqlConnection con = cn.obtener_conexion())
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandText = "DELETE FROM Participaciones WHERE idParticipacion = @id";
                cmd.Parameters.AddWithValue("@id", idParticipacion);
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        // Actualizar
        public static bool Actualizar(int idParticipacion, int idEmpleado, int idProyecto, string rol)
        {
            using (SqlConnection con = cn.obtener_conexion())
            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandText =
                @"UPDATE Participaciones
                  SET idEmpleado = @e,
                      idProyecto = @p,
                      Rol = @r
                  WHERE idParticipacion = @id";

                cmd.Parameters.AddWithValue("@e", idEmpleado);
                cmd.Parameters.AddWithValue("@p", idProyecto);
                cmd.Parameters.AddWithValue("@r", (object)rol ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@id", idParticipacion);

                return cmd.ExecuteNonQuery() > 0;
            }
        }
    }
}
