﻿namespace ExamenPOO1.Modelos
{
    public class Participaciones_models
    {
        public int IdParticipacion { get; set; }
        public int IdEmpleado { get; set; }
        public int IdProyecto { get; set; }
        public string Rol { get; set; }
    }
}
