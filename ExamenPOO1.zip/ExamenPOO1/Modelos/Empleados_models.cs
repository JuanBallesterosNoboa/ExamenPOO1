﻿namespace ExamenPOO1.Modelos
{
    public class Empleados_models
{
    public int IdEmpleado { get; set; }
    public string Nombre { get; set; }
    public string Puesto { get; set; }
}
}
