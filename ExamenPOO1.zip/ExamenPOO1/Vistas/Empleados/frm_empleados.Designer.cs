﻿namespace ExamenPOO1.Vistas.Empleados
{
    partial class frm_empleados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            dataGridView1 = new DataGridView();
            btn_insertar = new Button();
            btn_eliminar = new Button();
            txt_nombre = new TextBox();
            txt_puesto = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F);
            label1.Location = new Point(368, 9);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(292, 38);
            label1.TabIndex = 0;
            label1.Text = "Gestión de Empleados";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(20, 50);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(987, 238);
            dataGridView1.TabIndex = 1;
            // 
            // btn_insertar
            // 
            btn_insertar.Location = new Point(247, 416);
            btn_insertar.Name = "btn_insertar";
            btn_insertar.Size = new Size(233, 69);
            btn_insertar.TabIndex = 2;
            btn_insertar.Text = "Insertar";
            btn_insertar.UseVisualStyleBackColor = true;
            btn_insertar.Click += btn_insertar_Click;
            // 
            // btn_eliminar
            // 
            btn_eliminar.Location = new Point(594, 416);
            btn_eliminar.Name = "btn_eliminar";
            btn_eliminar.Size = new Size(226, 69);
            btn_eliminar.TabIndex = 3;
            btn_eliminar.Text = "Eliminar";
            btn_eliminar.UseVisualStyleBackColor = true;
            btn_eliminar.Click += btn_eliminar_Click;
            // 
            // txt_nombre
            // 
            txt_nombre.Location = new Point(149, 346);
            txt_nombre.Name = "txt_nombre";
            txt_nombre.Size = new Size(331, 45);
            txt_nombre.TabIndex = 4;
            // 
            // txt_puesto
            // 
            txt_puesto.Location = new Point(639, 346);
            txt_puesto.Name = "txt_puesto";
            txt_puesto.Size = new Size(307, 45);
            txt_puesto.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(14, 136);
            label2.Name = "label2";
            label2.Size = new Size(0, 38);
            label2.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(20, 291);
            label3.Name = "label3";
            label3.Size = new Size(511, 38);
            label3.TabIndex = 8;
            label3.Text = "Para añadir un usuario porfavor ingrese:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(24, 349);
            label4.Name = "label4";
            label4.Size = new Size(125, 38);
            label4.TabIndex = 9;
            label4.Text = "Nombre:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(507, 353);
            label5.Name = "label5";
            label5.Size = new Size(107, 38);
            label5.TabIndex = 10;
            label5.Text = "Puesto:";
            // 
            // frm_empleados
            // 
            AutoScaleDimensions = new SizeF(15F, 38F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1036, 497);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txt_puesto);
            Controls.Add(txt_nombre);
            Controls.Add(btn_eliminar);
            Controls.Add(btn_insertar);
            Controls.Add(dataGridView1);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 14F);
            Margin = new Padding(4, 5, 4, 5);
            Name = "frm_empleados";
            Text = "frm_empleados";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private DataGridView dataGridView1;
        private Button btn_insertar;
        private Button btn_eliminar;
        private TextBox txt_nombre;
        private TextBox txt_puesto;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
    }
}