﻿using ExamenPOO1.Controladores;

namespace ExamenPOO1.Vistas.Empleados
{
    public partial class frm_empleados : Form
    {
        public frm_empleados()
        {
            InitializeComponent();
            CargarTabla();
        }

        private void CargarTabla()
        {
            dataGridView1.DataSource = Empleados_Controller.Seleccionar();
        }

        private void btn_insertar_Click(object sender, EventArgs e)
        {
            Empleados_Controller.Insertar(txt_nombre.Text, txt_puesto.Text);
            CargarTabla();
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un empleado para eliminar.");
                return;
            }

            // Obtener ID desde la fila seleccionada
            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["idEmpleado"].Value);

            // Confirmación
            var result = MessageBox.Show("¿Eliminar este empleado?",
                                        "Confirmar",
                                        MessageBoxButtons.YesNo,
                                        MessageBoxIcon.Question);

            if (result == DialogResult.No)
                return;

           
            Empleados_Controller.Eliminar(id);

     
            CargarTabla();

            MessageBox.Show("Empleado eliminado correctamente.");
        }

    }
}