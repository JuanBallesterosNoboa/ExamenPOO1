﻿namespace ExamenPOO1.Vistas.Proyectos
{
    partial class frm_proyectos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_eliminarproyecto = new Button();
            btn_insertarproyecto = new Button();
            dataGridView1 = new DataGridView();
            label1 = new Label();
            label4 = new Label();
            label3 = new Label();
            txt_nombre = new TextBox();
            dateTimePicker1 = new DateTimePicker();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btn_elminarproyecto
            // 
            btn_eliminarproyecto.Enabled = true;
            btn_eliminarproyecto.Location = new Point(591, 429);
            btn_eliminarproyecto.Name = "btn_elminarproyecto";
            btn_eliminarproyecto.Size = new Size(181, 59);
            btn_eliminarproyecto.TabIndex = 7;
            btn_eliminarproyecto.Text = "Eliminar";
            btn_eliminarproyecto.UseVisualStyleBackColor = true;
            btn_eliminarproyecto.Click += btn_eliminarproyecto_Click;
            // 
            // btn_insertarproyecto
            // 
            btn_insertarproyecto.Location = new Point(296, 429);
            btn_insertarproyecto.Name = "btn_insertarproyecto";
            btn_insertarproyecto.Size = new Size(181, 59);
            btn_insertarproyecto.TabIndex = 6;
            btn_insertarproyecto.Text = "Insertar";
            btn_insertarproyecto.UseVisualStyleBackColor = true;
            btn_insertarproyecto.Click += btn_insertarproyecto_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(21, 61);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(998, 197);
            dataGridView1.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F);
            label1.Location = new Point(377, 20);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(279, 38);
            label1.TabIndex = 4;
            label1.Text = "Gestión de Proyectos";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(41, 349);
            label4.Name = "label4";
            label4.Size = new Size(296, 38);
            label4.TabIndex = 14;
            label4.Text = "Nombre del proyecto: ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(37, 291);
            label3.Name = "label3";
            label3.Size = new Size(529, 38);
            label3.TabIndex = 13;
            label3.Text = "Para añadir un proyecto porfavor ingrese:";
            // 
            // txt_nombre
            // 
            txt_nombre.Location = new Point(334, 349);
            txt_nombre.Name = "txt_nombre";
            txt_nombre.Size = new Size(407, 45);
            txt_nombre.TabIndex = 11;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(834, 349);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(194, 45);
            dateTimePicker1.TabIndex = 15;
           
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(747, 352);
            label2.Name = "label2";
            label2.Size = new Size(81, 38);
            label2.TabIndex = 16;
            label2.Text = "Inicia";
            // 
            // frm_proyectos
            // 
            AutoScaleDimensions = new SizeF(15F, 38F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1057, 512);
            Controls.Add(label2);
            Controls.Add(dateTimePicker1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(txt_nombre);
            Controls.Add(btn_eliminarproyecto);
            Controls.Add(btn_insertarproyecto);
            Controls.Add(dataGridView1);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 14F);
            Margin = new Padding(4, 5, 4, 5);
            Name = "frm_proyectos";
            Text = "frm_proyectos";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_eliminarproyecto;
        private Button btn_insertarproyecto;
        private DataGridView dataGridView1;
        private Label label1;
        private Label label4;
        private Label label3;
        private TextBox txt_nombre;
        private DateTimePicker dateTimePicker1;
        private Label label2;
    }
}