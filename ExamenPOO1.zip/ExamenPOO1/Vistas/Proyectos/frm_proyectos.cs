﻿using ExamenPOO1.Controladores;

namespace ExamenPOO1.Vistas.Proyectos
{
    public partial class frm_proyectos : Form
    {
        public frm_proyectos()
        {
            InitializeComponent();
            CargarTabla();
        }

        private void CargarTabla()
        {
            dataGridView1.DataSource = Proyectos_Controller.Seleccionarproyecto();
        }

        private void btn_insertarproyecto_Click(object sender, EventArgs e)
        {
            Proyectos_Controller.Insertarproyecto(
                txt_nombre.Text,
                dateTimePicker1.Value
            );

            CargarTabla();
        }

        private void btn_eliminarproyecto_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione un proyecto para eliminar.");
                return;
            }

            int id = Convert.ToInt32(
                dataGridView1.SelectedRows[0].Cells["idProyecto"].Value
            );

            Proyectos_Controller.Eliminarproyecto(id);
            CargarTabla();
        }
    }
}
