﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenPOO1.Vistas
{
    public partial class frm_dashboard : Form
    {
        public frm_dashboard()
        {
            InitializeComponent();
        }

        private void empleadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Vistas.Empleados.frm_empleados frm_Empleados = new Empleados.frm_empleados();
            frm_Empleados.ShowDialog();
        }

        private void proyectosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frm_Proyectos = new Proyectos.frm_proyectos();
            frm_Proyectos.ShowDialog();
        }

        private void participacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frm_Participaciones = new Participaciones.frm_participaciones();
            frm_Participaciones.ShowDialog();   
        }
    }
}
