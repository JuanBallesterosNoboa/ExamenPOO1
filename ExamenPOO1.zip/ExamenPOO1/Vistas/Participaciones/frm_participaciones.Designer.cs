﻿namespace ExamenPOO1.Vistas.Participaciones
{
    partial class frm_participaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgv_participaciones = new DataGridView();
            label1 = new Label();
            lst_empleados = new ListBox();
            btn_insertarparticipacion = new Button();
            cmb_proyectos = new ComboBox();
            btn_mostrardatos = new Button();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txt_rol = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgv_participaciones).BeginInit();
            SuspendLayout();
            // 
            // dgv_participaciones
            // 
            dgv_participaciones.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_participaciones.Location = new Point(595, 87);
            dgv_participaciones.Margin = new Padding(4, 5, 4, 5);
            dgv_participaciones.Name = "dgv_participaciones";
            dgv_participaciones.RowHeadersWidth = 62;
            dgv_participaciones.Size = new Size(421, 418);
            dgv_participaciones.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F);
            label1.Location = new Point(333, 21);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new Size(342, 38);
            label1.TabIndex = 4;
            label1.Text = "Gestión de Participaciones";
            // 
            // lst_empleados
            // 
            lst_empleados.FormattingEnabled = true;
            lst_empleados.ItemHeight = 38;
            lst_empleados.Location = new Point(12, 125);
            lst_empleados.Name = "lst_empleados";
            lst_empleados.Size = new Size(269, 384);
            lst_empleados.TabIndex = 6;
            // 
            // btn_insertarparticipacion
            // 
            btn_insertarparticipacion.Font = new Font("Segoe UI", 12F);
            btn_insertarparticipacion.Location = new Point(305, 363);
            btn_insertarparticipacion.Name = "btn_insertarparticipacion";
            btn_insertarparticipacion.Size = new Size(269, 49);
            btn_insertarparticipacion.TabIndex = 7;
            btn_insertarparticipacion.Text = "Insertar Participación";
            btn_insertarparticipacion.UseVisualStyleBackColor = true;
            btn_insertarparticipacion.Click += btn_insertarparticipacion_Click;
            // 
            // cmb_proyectos
            // 
            cmb_proyectos.FormattingEnabled = true;
            cmb_proyectos.Location = new Point(301, 125);
            cmb_proyectos.Name = "cmb_proyectos";
            cmb_proyectos.Size = new Size(269, 46);
            cmb_proyectos.TabIndex = 8;
            // 
            // btn_mostrardatos
            // 
            btn_mostrardatos.Font = new Font("Segoe UI", 12F);
            btn_mostrardatos.Location = new Point(301, 434);
            btn_mostrardatos.Name = "btn_mostrardatos";
            btn_mostrardatos.Size = new Size(269, 71);
            btn_mostrardatos.TabIndex = 9;
            btn_mostrardatos.Text = "Mostrar participaciones";
            btn_mostrardatos.UseVisualStyleBackColor = true;
            btn_mostrardatos.Click += btn_mostrardatos_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F);
            label2.Location = new Point(12, 87);
            label2.Name = "label2";
            label2.Size = new Size(179, 25);
            label2.TabIndex = 10;
            label2.Text = "Seleccione empleado";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F);
            label3.Location = new Point(301, 87);
            label3.Name = "label3";
            label3.Size = new Size(170, 25);
            label3.TabIndex = 11;
            label3.Text = "Seleccione proyecto";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F);
            label4.Location = new Point(301, 200);
            label4.Name = "label4";
            label4.Size = new Size(194, 25);
            label4.TabIndex = 12;
            label4.Text = "Indique el rol a cumplir";
            // 
            // txt_rol
            // 
            txt_rol.Location = new Point(301, 228);
            txt_rol.Name = "txt_rol";
            txt_rol.Size = new Size(273, 45);
            txt_rol.TabIndex = 13;
            // 
            // frm_participaciones
            // 
            AutoScaleDimensions = new SizeF(15F, 38F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1029, 533);
            Controls.Add(txt_rol);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btn_mostrardatos);
            Controls.Add(cmb_proyectos);
            Controls.Add(btn_insertarparticipacion);
            Controls.Add(lst_empleados);
            Controls.Add(dgv_participaciones);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 14F);
            Margin = new Padding(4, 5, 4, 5);
            Name = "frm_participaciones";
            Text = "frm_participaciones";
            ((System.ComponentModel.ISupportInitialize)dgv_participaciones).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView dgv_participaciones;
        private Label label1;
        private ListBox lst_empleados;
        private Button btn_insertarparticipacion;
        private ComboBox cmb_proyectos;
        private Button btn_mostrardatos;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txt_rol;
    }
}