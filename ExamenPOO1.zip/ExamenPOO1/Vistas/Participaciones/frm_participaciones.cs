﻿using System;
using System.Data;
using System.Windows.Forms;
using ExamenPOO1.Controladores;

namespace ExamenPOO1.Vistas.Participaciones
{
    public partial class frm_participaciones : Form
    {
        public frm_participaciones()
        {
            InitializeComponent();
            Inicializar();
        }

        private void Inicializar()
        {
            CargarEmpleados();
            CargarProyectos();
            CargarTodasParticipaciones();

            dgv_participaciones.MultiSelect = false;
            dgv_participaciones.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void CargarEmpleados()
        {
            lst_empleados.DataSource = Empleados_Controller.Seleccionar();
            lst_empleados.DisplayMember = "Nombre";
            lst_empleados.ValueMember = "idEmpleado";
        }

        private void CargarProyectos()
        {
            cmb_proyectos.DataSource = Proyectos_Controller.Seleccionarproyecto();
            cmb_proyectos.DisplayMember = "Nombre";
            cmb_proyectos.ValueMember = "idProyecto";
        }

        private void CargarTodasParticipaciones()
        {
            dgv_participaciones.DataSource = Participaciones_Controller.SeleccionarTodas();
        }

        private void CargarPorProyecto()
        {
            if (cmb_proyectos.SelectedIndex == -1) return;

            int idProyecto = Convert.ToInt32(cmb_proyectos.SelectedValue);
            dgv_participaciones.DataSource = Participaciones_Controller.SeleccionarPorProyecto(idProyecto);
        }

        private void btn_insertarparticipacion_Click(object sender, EventArgs e)
        {
            if (lst_empleados.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccione un empleado.");
                return;
            }

            if (cmb_proyectos.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccione un proyecto.");
                return;
            }

            int idEmpleado = Convert.ToInt32(lst_empleados.SelectedValue);
            int idProyecto = Convert.ToInt32(cmb_proyectos.SelectedValue);
            string rol = txt_rol.Text.Trim();

            Participaciones_Controller.Insertar(idEmpleado, idProyecto, rol);

            MessageBox.Show("Participación insertada correctamente.");

            CargarPorProyecto();
            txt_rol.Clear();
        }

        private void btn_mostrardatos_Click(object sender, EventArgs e)
        {
            CargarPorProyecto();
        }
    }
}
