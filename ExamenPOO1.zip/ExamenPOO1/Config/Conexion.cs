﻿using Microsoft.Data.SqlClient;

namespace ExamenPOO1.Config
{
    public class Conexion
    {
        private readonly string cadena_conexion =
            "Server=JUAN\\MSSQLSERVER01;Database=Basededatosexamen;Integrated Security=True;TrustServerCertificate=True;";

        public SqlConnection obtener_conexion()
        {
            SqlConnection cn = new SqlConnection(cadena_conexion);
            cn.Open();
            return cn;
        }
    }
}
